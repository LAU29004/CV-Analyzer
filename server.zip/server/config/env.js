export const ENABLE_AI = process.env.ENABLE_AI === "true";
