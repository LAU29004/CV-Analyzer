export const logAI = (message, meta = {}) => {
  console.log(`[AI] ${message}`, meta);
};
